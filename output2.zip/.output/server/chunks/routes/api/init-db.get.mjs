import { d as defineEventHandler, c as createError } from '../../nitro/nitro.mjs';
import { p as pool } from '../../_/db.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';

const initDb_get = defineEventHandler(async (event) => {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS games (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        cover VARCHAR(500) NOT NULL,
        description TEXT,
        steam_id VARCHAR(50),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_created_at (created_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);
    return {
      success: true,
      message: "\u6570\u636E\u5E93\u8868\u521B\u5EFA\u6210\u529F"
    };
  } catch (error) {
    console.error("\u521D\u59CB\u5316\u6570\u636E\u5E93\u5931\u8D25:", error);
    throw createError({
      statusCode: 500,
      message: "\u521D\u59CB\u5316\u6570\u636E\u5E93\u5931\u8D25: " + error.message
    });
  }
});

export { initDb_get as default };
//# sourceMappingURL=init-db.get.mjs.map
