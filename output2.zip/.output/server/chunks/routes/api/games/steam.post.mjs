import { d as defineEventHandler, r as readBody, c as createError } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const steam_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const appId = String((body == null ? void 0 : body.appId) || "").trim();
  if (!/^\d+$/.test(appId)) {
    throw createError({
      statusCode: 400,
      message: "appId \u7F3A\u5931\u6216\u683C\u5F0F\u975E\u6CD5"
    });
  }
  try {
    const response = await $fetch(`https://store.steampowered.com/api/appdetails?appids=${appId}&l=schinese`);
    const appData = response == null ? void 0 : response[appId];
    if (!appData || appData.success !== true || !appData.data) {
      throw createError({
        statusCode: 404,
        message: "\u672A\u627E\u5230\u5BF9\u5E94\u7684 Steam \u6E38\u620F"
      });
    }
    const data = appData.data;
    const title = String(data.name || "").trim();
    const cover = String(data.header_image || "").trim();
    const shortDescription = String(data.short_description || "").trim();
    const detailedDescription = String(data.detailed_description || "").replace(/<[^>]+>/g, " ").replace(/&nbsp;/gi, " ").replace(/&amp;/gi, "&").replace(/\s+/g, " ").trim();
    const description = shortDescription || detailedDescription || "";
    if (!title || !cover) {
      throw createError({
        statusCode: 502,
        message: "Steam \u8FD4\u56DE\u7684\u6570\u636E\u4E0D\u5B8C\u6574"
      });
    }
    return {
      title,
      cover,
      description,
      steamId: appId
    };
  } catch (error) {
    if (error == null ? void 0 : error.statusCode) {
      throw error;
    }
    console.error("\u83B7\u53D6 Steam \u6E38\u620F\u4FE1\u606F\u5931\u8D25:", error);
    throw createError({
      statusCode: 502,
      message: "Steam \u670D\u52A1\u8BF7\u6C42\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5"
    });
  }
});

export { steam_post as default };
//# sourceMappingURL=steam.post.mjs.map
