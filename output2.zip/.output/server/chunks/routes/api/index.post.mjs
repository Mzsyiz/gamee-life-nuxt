import { d as defineEventHandler, r as readBody, c as createError } from '../../nitro/nitro.mjs';
import { p as pool } from '../../_/db.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';

const index_post = defineEventHandler(async (event) => {
  try {
    const body = await readBody(event);
    const { title, cover, description, steamId } = body;
    if (!title || !cover) {
      throw createError({
        statusCode: 400,
        message: "\u6807\u9898\u548C\u5C01\u9762\u662F\u5FC5\u586B\u9879"
      });
    }
    const [result] = await pool.query(
      "INSERT INTO games (title, cover, description, steam_id) VALUES (?, ?, ?, ?)",
      [title, cover, description || "", steamId || null]
    );
    return {
      success: true,
      id: result.insertId,
      message: "\u6E38\u620F\u6DFB\u52A0\u6210\u529F"
    };
  } catch (error) {
    console.error("\u6DFB\u52A0\u6E38\u620F\u5931\u8D25:", error);
    throw createError({
      statusCode: error.statusCode || 500,
      message: error.message || "\u6DFB\u52A0\u6E38\u620F\u5931\u8D25"
    });
  }
});

export { index_post as default };
//# sourceMappingURL=index.post.mjs.map
