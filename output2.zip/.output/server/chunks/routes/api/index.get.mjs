import { d as defineEventHandler, c as createError } from '../../nitro/nitro.mjs';
import { p as pool } from '../../_/db.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'mysql2/promise';

const index_get = defineEventHandler(async (event) => {
  try {
    const [rows] = await pool.query(
      "SELECT * FROM games ORDER BY created_at DESC"
    );
    return rows;
  } catch (error) {
    console.error("\u83B7\u53D6\u6E38\u620F\u5217\u8868\u5931\u8D25:", error);
    throw createError({
      statusCode: 500,
      message: "\u83B7\u53D6\u6E38\u620F\u5217\u8868\u5931\u8D25"
    });
  }
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
