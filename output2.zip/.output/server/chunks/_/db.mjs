import mysql from 'mysql2/promise';

const pool = mysql.createPool({
  host: "49.233.0.178",
  user: "gamelife",
  password: "ezem4yWPJxkKhh8c",
  database: "gamelife",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

export { pool as p };
//# sourceMappingURL=db.mjs.map
